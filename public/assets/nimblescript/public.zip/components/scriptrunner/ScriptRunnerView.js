define(['require', 'backbone', 'marionette', 'jquery', 'App', 'swig', 'logger', 'text!./scriptrunner.html',
    'css!./scriptrunner.css', './sections/parameters/ParametersView', './sections/result/ResultView', './sections/summary/SummaryView', 'select2/select2',
    'modalhelper'],
    function (require, Backbone, Marionette, $, App, Swig, Logger, html, css, ParametersView,
        ResultView, SummaryView, $select2, ModalHelper)
    {
        "use strict"

        var instanceId = 1;
        return Marionette.Layout.extend(
            {
                constructor: function ()
                {
                    _.bindAll(this);
                    Marionette.Layout.prototype.constructor.apply(this, arguments);
                },
                events: {
                    'click a[action=run]:not(.disabled)': 'run',
                    'click a[action=reset]:not(.disabled)': 'reset',
                    'click a[action=edit-script]': 'editScript',
                    'click a[action=save-param]': 'saveParameters',
                    'click a[action=load-param]': 'loadSavedParameters',
                    'click a[action=delete-param]': 'deleteSavedParameters'
                },
                ui: {
                    'savedParamList': 'select.saved-parameters',
                    'runResult': '.runresult'
                },
                template: Swig.compile(html),
                tagName: 'div',
                className: 'script-runner',
                regions: {
                    summaryRegion: '.run-script-summary-section',
                    parametersRegion: '.run-script-parameters',
                    resultRegion: '.run-script-results-section'
                },
                initialize: function ()
                {
                    this.model = new Backbone.Model(_.extend({}, this.options.data, { id: instanceId++ },
                        _.pick(this.options, 'showDetails', 'showResult', 'showParameters')));
                    this._scriptManager = App.request('scripts:getmanager');
                    this.listenTo(this._scriptManager, 'params', this.onSavedParametersEvent);
                },
                onRender: function ()
                {
                    this.summaryView = new SummaryView({ model: this.model });
                    this.summaryRegion.show(this.summaryView);
                    this.parametersView = new ParametersView({ model: this.model });
                    this.parametersRegion.show(this.parametersView);
                    this.resultView = new ResultView({ model: this.model });
                    this.resultRegion.show(this.resultView);
                    this.populateSavedParamList();
                    
                    if (this.options.paramValues)
                        this.setParameterValues(this.options.paramValues);
                    if (this.options.run)
                        this.run();
                },
                /* Custom */
                afterShow: function()
                {
                    this.resultView.onShow();
                    this.parametersView.onShow();
                    this.summaryView.onShow();
                },
                populateSavedParamList: function ()
                {
                    var self = this;
                    this._scriptManager.getSavedParameters(null, function (err, savedParamList)
                    {
                        if (!err)
                        {
                            var current = self.ui.savedParamList.val();
                            self.ui.savedParamList.empty();
                            self.ui.savedParamList.addSelectOption('<New>', '', _.isEmpty(current))
                            _.each(savedParamList, function (savedParamName)
                            {
                                self.ui.savedParamList.addSelectOption(savedParamName, savedParamName, _.isEqual(current, savedParamName));
                            })
                            self.ui.savedParamList.select2();
                        }
                    });
                },
                run: function ()
                {
                    var validationErrors = this.parametersView.validate();
                    if (!validationErrors)
                    {
                        var params = this.parametersView.getValues();
                        this.$el.find('a[action=run]').buttonDisable($.t('script.running'));
                        this.$el.find('a[action=reset]').buttonDisable();
                        this.setResult($.t('script.running'), 'info');

                        var self = this;

                        this._scriptManager.runScript(this.options.data.scriptpath, { parameters: this.getParameterValues() }, function (err, response)
                        {
                            self.toggleSection('result', false);
                            self.$el.find('a[action=run]').buttonEnable();
                            self.$el.find('a[action=reset]').buttonEnable();
                            if (err)
                            {
                                self.setResult($.t('script.error'), 'important', $.t('script.run_error'));
                            }
                            else
                                self.processResponse(response)
                        });
                    }
                    else
                    {
                        this.setResult($.t('script.parameter_errors'), 'important');
                    }
                    return validationErrors;
                },
                processResponse: function (response)
                {
                    response.success && this.processResponseReturn(response);
                    !response.success && this.processResponseError(response);

                },
                processResponseReturn: function (response)
                {
                    var returnData = response.returndata
                        , self = this
                        , scriptOutput;

                    var responseProcessors = {
                        'success': this.processResponseSuccess,
                        'dataerror': this.processResponseDataError,
                        'runerror': this.processResponseRunError
                    };
                    if (responseProcessors[returnData.runresult])
                        responseProcessors[returnData.runresult](returnData, scriptOutput);
                    else
                        self.setResult($.t('script.script_error'), 'important', $.t('unknown_runresult'));
                },
                parseScriptOutput: function (output)
                {
                    try
                    {
                        return JSON.parse(output);
                    }
                    catch (e)
                    {
                        return output;
                    }
                },
                processResponseSuccess: function (returnData)
                {
                    this.setResult($.t('script.success'), 'success', this.parseScriptOutput(returnData.output), returnData.filelists);
                },
                processResponseDataError: function (returnData)
                {
                    var message = $.t('script.run_parameter_error');
                    if (returnData.message)
                        message += '\n\n' + returnData.message;
                    if (returnData.parameterErrors)
                        this.parametersView.setParameterErrors(returnData.parameterErrors);

                    this.setResult($.t('script.data_error'), 'important', message);
                },
                processResponseRunError: function (returnData)
                {
                    var message = $.t('script.run_execution_error');
                    if (returnData.message)
                        message += '\n\n' + returnData.message;
                    this.setResult($.t('script.run_error'), 'important', message);
                },
                processResponseError: function (response)
                {
                    this.setResult($.t('script.script_error'), 'important', response.messages.join('\n'));
                },
                setResult: function (result, level, output, fileLists)
                {
                    this.ui.runResult.text(result).removeClass('label-important label-success label-warning label-info').addClass('label-' + level);
                    this.model.set('result',
                        { output: output && (_.isObject(output) ? JSON.stringify(output, null, 4) : output.toString()), filelists: fileLists });
                },
                selectedSavedParamList: function ()
                {
                    return this.ui.savedParamList.val();
                },
                loadSavedParameters: function ()
                {
                    var self = this;
                    var savedParamName = this.selectedSavedParamList();
                    if (!_.isEmpty(savedParamName))
                    {
                        this._scriptManager.loadSavedParameters(savedParamName, function (err, savedParameters)
                        {
                            self.setParameterValues(savedParameters);
                        });
                    }
                },
                saveParameters: function ()
                {
                    var self = this;
                    var savedParamName = this.selectedSavedParamList();
                    if (_.isEmpty(savedParamName))
                    {
                        var modal = new ModalHelper().prompt({
                            title: 'Save parameters...',
                            text: 'Specify name to save as',
                            onButton: function (text)
                            {
                                if (text == 'OK')
                                {
                                    var name = modal.find('input.active').val();
                                    var r = /[A-Za-z\-_\s0-9]+/;
                                    if (!name.match(r))
                                    {
                                        new ModalHelper().alert({ title: 'Error...', text: 'Only following characters are supported:<br/> A-Z, a-z, 0-9, _, -, and spaces' });
                                        return false;
                                    }
                                    doSave(name);
                                }
                                return true;
                            }
                        });
                    }
                    else
                        doSave(savedParamName);


                    function doSave(name)
                    {
                        self._savingParameters = true;
                        self._scriptManager.saveParameters(name, { values: self.getParameterValues(), scriptpath: self.options.data.scriptpath }, function (err)
                        {
                            if (err)
                                new ModalHelper().error(err)
                            self._savingParameters = false;

                        });
                    }

                },
                deleteSavedParameters: function ()
                {
                    var self = this;
                    var savedParamName = this.selectedSavedParamList();
                    if (!_.isEmpty(savedParamName))
                        self._scriptManager.deleteSavedParameters(savedParamName, function (err)
                        {
                            err && new ModalHelper().error(err)
                        });
                },
                onSavedParametersEvent: function (eventType, name)
                {
                    var savedParamName = this.selectedSavedParamList();
                    switch (eventType)
                    {
                        case 'saved':
                            this.ui.savedParamList.addSelectOption(name, name);
                            break;
                        case 'deleted':
                            this.ui.savedParamList.children('option[value="' + name + '"]').remove();
                            // Set <New> selected if deleted is current
                            if (_.isEqual(name, savedParamName))
                                this.ui.savedParamList.children().eq(0).prop('selected', true);
                            break;
                    }
                    this.ui.savedParamList.select2('val', this._savingParameters ? name : savedParamName);
                },
                getParameterValues: function ()
                {
                    return this.parametersView.getValues();
                },
                setParameterValues: function (values)
                {
                    this.parametersView.setValues(values);
                },
                reset: function ()
                {
                    this.parametersView.reset();
                    this.setResult('');
                },
                editScript: function ()
                {
                    this._scriptManager.editScript(this.options.data.iteminfo.path);
                },
                toggleSection: function (sectionName, collapse)
                {
                    var $section = this.$el.find('[section="' + sectionName + '"]');

                    if (!collapse && !$section.hasClass('in'))
                        $section.collapse('show');

                    if (collapse)
                        $section.collapse({ toggle: false }).collapse('hide');
                }

            });
    }
)
