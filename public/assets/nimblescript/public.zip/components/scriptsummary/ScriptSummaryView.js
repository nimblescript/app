define(['require', 'backbone', 'marionette', 'jquery', 'App', 'swig', 'logger', 'text!./scriptsummary.html','css!./scriptsummary'],
    function (require, Backbone, Marionette, $, App, Swig, Logger, scriptSummaryHtml)
    {
        "use strict"

        return Marionette.ItemView.extend(
            {
                constructor: function ()
                {
                    _.bindAll(this);
                    Marionette.ItemView.prototype.constructor.apply(this, arguments);
                },
                modelEvents: {
                    "change": "render"
                },
                template: Swig.compile(scriptSummaryHtml),
                tagName: 'div',
                initialize: function()
                {
                    this.model = new Backbone.Model();
                    this._repositoryManager = App.request('repository:getmanager');
                    this._scriptManager = App.request('scripts:getmanager');
                    this._super();

                },
                loadSummary: function (scriptPath)
                {
                    var self = this;
                    this._scriptManager.getScriptSummary(scriptPath, function (err, response)
                    {
                        if (err)
                            self.setEmpty();
                        else
                            updateModel(self.model, response.returndata.title, response.returndata.description, response.returndata.version, response.returndata.author)
                    });
                    
                },

                setEmpty: function ()
                {
                    updateModel(this.model)
                }

            });

        function updateModel(model,title, description, version, author)
        {
            model.set({
                title: title,
                description: description,
                version: version,
                author: author
            })
        }
    }
)
