﻿define(function (require, exports, module)
{
    "use strict"

    module.exports = function (register)
    {
        var _ = require('underscore')
            , $ = require('jquery')
            , Backbone = require('backbone')
            , App = require('App')
            , Logger = require('logger')
            , KeyboardShortcuts = require('keyboardshortcuts')
            , Document = require('document')
            

        init();

        register(
            {
                id: 'xemware.nimblescript.plugin.marketplace',
                about: function ()
                {
                    return "Adds Marketplace functionality"
                },
                version: function ()
                {
                    return "0.0.1"
                }
            }
        );

        var repositoryManager = App.request('repository:getmanager');

        function MarketplaceManager()
        {
        }

        _.extend(MarketplaceManager.prototype, Backbone.Events,
            {
                search: function (options)
                {
                    var self = this;
                    options = _.defaults({}, options, { repository: 'local' });
                    return App.serverCommand(
                        {
                            url: '/filelists',
                            data: { rep: options.repository },
                            success: function (response)
                            {
                                var lists = self.cache[options.repository] = _.map(response.filelists, function (name)
                                {
                                    return { name: name };
                                });
                                options.callback && options.callback(null, lists);

                            },
                            error: function ()
                            {
                                options.callback && options.callback(arguments);
                            }
                        })
                },
                isAuthorized: function ()
                {
                    var settingsManager = App.request('settings:getmanager');
                    return !_.isEmpty(settingsManager.lastUserSettings.marketplace.access_token);
                },
                authorize: function (callback)
                {
                    var self = this;
                    var settingsManager = App.request('settings:getmanager');
                    require(['modalhelper'], function (ModalHelper)
                    {
                        new ModalHelper().confirm({
                            title: 'Marketplace...', text: $.t('marketplace.authorize_page'),
                            onButton: function (text)
                            {
                                if (text == 'Yes')
                                {
                                    var path = settingsManager.lastUserSettings.marketplace.url + '/oauth/authorize?client_id=' + settingsManager.lastUserSettings.marketplace.client_id
                                        + '&redirect_uri=' + encodeURIComponent(location.protocol + '//' + location.host + '/marketplace/auth?install=1');

                                    window.marketplaceAuthDone = function (accessToken)
                                    {
                                        if (_.isString(accessToken) && !_.isEmpty(accessToken))
                                        {
                                            settingsManager.loadSettings(function ()
                                            {
                                                callback && callback(true);
                                            });
                                        }
                                    }
                                    window.open(path, 'nsmarketplaceauth', 'location=0,status=0,width=800,height=400');
                                }

                            }
                        })
                    });
                },
                getItemInfo: function (installCode, callback)
                {
                    return App.serverCommand(
                        {
                            url: 'marketplace/item/' + encodeURIComponent(installCode) + '/info',
                            success: function (response)
                            {
                                callback && callback(null, response)
                            },
                            error: function ()
                            {
                                callback && callback(arguments);
                            }
                        })
                },
                installItem: function(installCode, options, callback)
                {
                    return App.serverCommand(
                        {
                            url: 'marketplace/item/' + encodeURIComponent(installCode) + '/install',
                            data: options,
                            type: 'POST',
                            success: function (response)
                            {
                                if (_.result(response, 'success') && response.item_type == 'script')
                                    repositoryManager.externalItemAction('saved',response.install_path, 'script')
                                callback && callback(null, response)
                            },
                            error: function ()
                            {
                                callback && callback(arguments);
                            }
                        })

                },
                quickInstallModal: function ()
                {
                    quickInstallModal();
                }
            })

        var marketplaceManager = new MarketplaceManager();

        function init()
        {
            App.reqres.setHandler('marketplace:getmanager', function ()
            {
                return marketplaceManager;
            })
            addToMenu();

        }


        function addToMenu()
        {
            var menuManager = App.request('menu:getmanager');
            var editMenu = _.first(menuManager.collection.where({ id: 'edit' }));
            var editPosition = menuManager.collection.models.indexOf(editMenu);
            menuManager.collection.add([{
                id: 'marketplace',
                label: 'Marketplace',
                href: '#',
                subitems: new Backbone.Collection([{
                    id: 'marketplace.browse',
                    label: 'Browse',
                    href: '#',
                    shortcut: 'Ctrl-Alt-M',
                    command: 'marketplace:browse',
                    disabled: true
                },
                {
                    id: 'marketplace.install',
                    label: 'Quick Install',
                    href: '#',
                    shortcut: 'Ctrl-Alt-I',
                    command: 'marketplace:install'
                }])
            }], { at: editPosition + 1 });

            KeyboardShortcuts.bind('ctrl+alt+i', function (e)
            {
                KeyboardShortcuts.preventDefault(e);
                quickInstallModal();
            })
            KeyboardShortcuts.bind('ctrl+alt+m', function (e)
            {
                KeyboardShortcuts.preventDefault(e);
                newBrowserDocument();
            })

            App.commands.setHandler('marketplace:browse', function ()
            {
                newBrowserDocument();
            });

            App.commands.setHandler('marketplace:install', function ()
            {
                quickInstallModal();
            });

        }

        function newBrowserDocument()
        {
            var documentManager = App.request('documents:getmanager');
            documentManager.addDocument(new BrowserDocument({ marketplaceManager: marketplaceManager } ));
        }

        function quickInstallModal()
        {
            require(['./MarketplaceInstallView', 'modalhelper'], function (MarketplaceInstallView,ModalHelper)
            {
                App.request('modules:getmanager').installedModules(function (modules)
                {
                    var userSettings = App.request('settings:getmanager').lastUserSettings;
                    var view = new MarketplaceInstallView({
                        marketplaceManager: marketplaceManager,
                        installedModules: _.map(modules, function(module)
                        {
                            return module.id
                        }),
                        enabledModules: userSettings.enabledModules,
                        marketplace: _.pick(userSettings.marketplace, 'url')
                    });
                    
                    var modalHelper = new ModalHelper();
                    modalHelper.view({
                        focusOn: 'input',
                        buttons: [{ text: 'Close', defaultButton: true }],
                        title: 'Install from Marketplace',
                        view: view
                    });

                    view.listenTo(view, 'item:installed', function ()
                    {
                        modalHelper.close();
                    })


                });
                
            });
        }

        var BrowserDocument = Document.extend(
            {
                constructor: function (options)
                {
                    _.bindAll(this);
                    Document.prototype.constructor.apply(this, arguments);
                    this.options = options || {};
                },
                title: 'Marketplace Browser',
                documentType: 'xemware.document.marketplace.browser',
                renderContent: function (callback)
                {
                    var settingsManager = App.request('settings:getmanager');
                    var self = this;
                    require(['./MarketplaceBrowserView'], function (MarketplaceBrowserView)
                    {
                        self.view = new MarketplaceBrowserView(this.options);
                        callback(self.view.render().$el)
                    })
                }
            })

    }
}
);