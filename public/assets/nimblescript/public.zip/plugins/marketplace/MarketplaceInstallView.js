﻿define(['marionette', 'backbone', 'underscore', 'swig', 'vent', 'jquery', 'App', 'text!./install.html','./ItemDetailsView','modalhelper'],
    function (Marionette, Backbone, _, Swig, Vent, $, App, html, ItemDetailsView,ModalHelper)
    {
        "use strict";

        var WAITING_TEXT = 'Please wait...';
        return Marionette.Layout.extend({
            constructor: function ()
            {
                _.bindAll(this);
                Marionette.Layout.prototype.constructor.apply(this, arguments);
            },
            template: Swig.compile(html),
            className: 'marketplace-install',
            initialize: function()
            {
                this._marketplaceManager = this.options.marketplaceManager;
                console.log(this.options);
                this._detailsView = new ItemDetailsView({
                    model: new Backbone.Model({
                        enabled_modules: this.options.enabledModules,
                        installed_modules: this.options.installedModules,
                        marketplace: this.options.marketplace
                    })
                })
                this._itemTypeHandlers = { script: this.installScript, module: this.installModule };
            },
            events:
                {
                    'click button.search': function (e) { this.search() },
                    'click button.install': function (e) { this.install() },
                    'keyup input': function (e) { if (e.keyCode == 13) this.search(); }
                },
            ui: {
                    installCode: '.install-code',
                    searchButton: 'button.search',
                    installButton: 'button.install'
                },
            regions:
                {
                    itemDetails: '.item-details'
                },
            onRender: function()
            {
                this.itemDetails.show(this._detailsView);
            },
            search: function(code, install)
            {
                var self = this;
                if (!this._marketplaceManager.isAuthorized())
                {
                    this._marketplaceManager.authorize(function (success)
                    {
                        if (success)
                            self.search(code,install);
                    });
                    return;
                }
                if (_.isEmpty(code))
                    code = this.ui.installCode.val();

                if (_.isEmpty(code))
                    return;

                
                this.ui.searchButton.buttonDisable(WAITING_TEXT);
                this.ui.installButton.buttonDisable(WAITING_TEXT);
                this._marketplaceManager.getItemInfo(code, function (err, response)
                {
                    self.ui.searchButton.buttonEnable();
                    self.ui.installButton.buttonEnable()[_.result(response,'success') ? 'show' : 'hide']();
                    self._detailsView.model.set('item', response && response.item_info);
                    self._currentItem = response.item_info;
                    
                });
            },
            install: function (code)
            {
                var self = this;

                if (_.isEmpty(code))
                    code = this.ui.installCode.val();

                if (_.isEmpty(code))
                    return;
                
                if (this._marketplaceManager.isAuthorized())
                {
                    this._itemTypeHandlers[this._currentItem.item_type](code);
                }
                else
                    this._marketplaceManager.authorize(function (success)
                    {
                        if (success)
                            self.install();
                    });
            },
            installScript: function (code)
            {
                var self = this;
                App.execute('components:get', ['xemware.nimblescript.component.repositoryexplorer'], function (err, Components)
                {
                    var modal = Components[0].showModal({
                        mode: 'save', overwritePrompt: true,
                        initialFilename: self._currentItem.name + '.ns',
                        onOK: function (selectedItems,callback)
                        {
                            self.ui.searchButton.buttonDisable(WAITING_TEXT);
                            self.ui.installButton.buttonDisable(WAITING_TEXT);
                            callback(true);

                            self._marketplaceManager.installItem(code, { destfilepath: modal.getDirectory() + '/' + modal.getFilename() },
                                function (err, response)
                                {
                                    self.ui.searchButton.buttonEnable();
                                    self.ui.installButton.buttonEnable();
                                    if (err || !response.success)
                                    {
                                        new ModalHelper().error(err || response);
                                    }
                                    else
                                    {
                                        new ModalHelper().alert({
                                            text: 'Item installed',
                                            title: 'Marketplace Download...',
                                            onButton: function (text)
                                            {
                                                self.trigger('item:installed', response);
                                            }
                                        });
                                    }
                                });
                        }
                    });
                });
            },
            installModule: function ()
            {

            }

        })
    }
)