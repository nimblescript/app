﻿define(['marionette', 'backbone', 'underscore', 'swig', 'vent', 'jquery', 'App', 'extendable/BaseEditItemView',
    'text!./firsttime.html', 'text!content/license.html', 'text!content/formerror.html'],
    function (Marionette, Backbone, _, Swig, Vent, $, App, BaseEditItemView, firstTimeHtml, licenseHtml, formErrorHtml)
    {
        "use strict";
        return BaseEditItemView.extend({
            formTemplate: Swig.compile(firstTimeHtml),
            template: Swig.compile(''),
            className: 'firstime-form',
            events:
                {
                    'submit form': 'submit'
                },
            schema: {
                password: {
                    type: 'Password', title: 'Password', key: 'password', validators: ['required',
                    { type: 'match', field: 'confirmpassword', message: 'Passwords must match!' }], attachToParent: true
                },
                confirmpassword: {
                    type: 'Password', title: 'Confirm Password', key: 'confirmpassword', attachToParent: true,
                    validators: ['required']
                },
                agreetolicense: {
                    type: 'Checkbox', title: 'Agree to License', key: 'agreetolicense', attachToParent: true,
                    validators: ['required']
                }


            },
            onRender: function ()
            {
                this._super();
                this.$el.find('#license').html(licenseHtml);
            },
            submit: function ()
            {
                var self = this;
                var userManager = App.request('user:getmanager');
                this.validate(function (result, errors)
                {
                    if (!errors)
                    {
                        App.serverCommand({
                            url: '/user/firsttime',
                            data: self.form.getValue(),
                            type: 'POST',
                            success: function (data)
                            {
                                if (data.success)
                                {
                                    userManager.trigger('userinit');
                                }
                                else
                                {
                                    var v = new Marionette.ItemView({
                                        template: Swig.compile(formErrorHtml),
                                        model: new Backbone.Model({
                                            errors: _.map(data.messages, function (v)
                                            {
                                                return { message: v }
                                            }
                                            )
                                        })
                                    }).render();
                                    self.$el.find('.error-block').append(v.$el);
                                }
                            },
                            error: function ()
                            {

                            }
                        });

                    }
                });
                return false;
            }
        })
    }
)